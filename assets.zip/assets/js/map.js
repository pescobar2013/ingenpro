
//var myCenter = new google.maps.LatLng(-33.433146,-70.6125711);//Providencia
var myCenter = new google.maps.LatLng(-33.4047056,-70.5885706,17z); //Las Condes

function initialize() {
var mapProp = {
  center:myCenter,
  zoom:14,
  scrollwheel:false,
  draggable:false,
  mapTypeId:google.maps.MapTypeId.ROADMAP
  };

var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

var marker = new google.maps.Marker({
  position:myCenter,
  animation: google.maps.Animation.DROP,
  });

marker.setMap(map);
}
google.maps.event.addDomListener(window, 'load', initialize);