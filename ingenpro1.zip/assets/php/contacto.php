<?php
//Comprobamos que se haya presionado el boton enviar
if(isset($_POST['submit'])){
//Guardamos en variables los datos enviados
$nombre = $_POST['nombre'];
$email = $_POST['email'];
$telefono = $_POST['telefono'];
$mensaje = $_POST['mensaje'];

/**
echo $nombre;
echo $email;
echo $telefono;
echo $mensaje;
**/
 
///Validamos del lado del servidor que el nombre y el email no estén vacios
if($nombre == ''){
echo "Debe ingresar su nombre";
}
else if($email == ''){
echo "Debe ingresar su email";
}else{
$para = "contacto@ingenpro.com, patricio.escobar@outlook.cl, patricio.e.escobar@gmail.com, patricio.escobar@ingenpro.com, alejandra.prieto@ingenpro.com";//Email al que se enviará
//$para = "patricio.escobar@outlook.cl";//Email al que se enviará
$asunto = "Contacto para su sitio web INGENPRO";//Puedes cambiar el asunto del mensaje desde aqui
//Este sería el cuerpo del mensaje
$informacion =
"
<html xmlns='http://www.w3.org/1999/xhtml'>
	<head>
		<meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
		<title>Untitled Document</title>
	</head>
	<body>
		<table border='0' cellspacing='3' cellpadding='2'>
			<tr>
				<td width='30%' align='left' bgcolor='#f0efef'><strong>Nombre:</strong></td>
				<td width='80%' align='left'>$nombre</td>	
			</tr>
			<tr>
				<td align='left' bgcolor='#f0efef'><strong>E-mail:</strong></td>
				<td align='left'>$email</td>
			</tr>
			<tr>
				<td width='30%' align='left' bgcolor='#f0efef'><strong>Teléfono:</strong></td>
				<td width='70%' align='left'>$telefono</td>
			</tr>
			<tr>
				<td align='left' bgcolor='#f0efef'><strong>Comentario:</strong></td>
				<td align='left'>$mensaje</td>
			</tr>
		</table>
	</body>
</html>
";
 
//Cabeceras del correo
//$headers = "From: $nombre <$email>\r\n"; //Quien envia?
//$headers .= "X-Mailer: PHP5\n";
//$headers .= 'MIME-Version: 1.0' . "\n";
//$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; //

$headers = 'From: contacto@ingenpro.com' . "\r\n" . //La direccion de correo desde donde supuestamente se envió
    'Reply-To: contacto@ingenpro.com' . "\r\n" . //La direccion de correo a donde se responderá (cuando el recepto haga click en RESPONDER)
    'Content-type: text/html; charset=utf-8' . "\r\n". // correo html
	'X-Mailer: PHP/' . phpversion();  //información sobre el sistema de envio de correos, en este caso la version de PHP
 

//mail($para, $asunto, $informacion, $headers);
if(mail($para, $asunto, $informacion, $headers)){
echo "Su mensaje se ha enviado correctamente, pronto lo contactaremos";
echo "<br />";
echo "<br />";
echo "Saludos Cordiales,";
echo "<br />";
echo "<br />";
echo "IngenPro Ingenieros El&eacute;ctricos";
echo "<br />";
echo "<br />";
echo '<a href="../../index.html">Volver</a>';
}else{
echo "Hubo un error en el envío inténtelo más tarde";
}

//Comprobamos que los datos enviados a la función MAIL de PHP estén bien y si es correcto enviamos

}
}
?>